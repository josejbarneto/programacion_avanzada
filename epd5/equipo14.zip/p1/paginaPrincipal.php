<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

echo '<nav>
            <a href="index.php">Crear Aerolinea</a>
            <a href="index2.php">Crear conexion</a>
            <a href="index3.php">Informacion</a>
        </nav>';